/* cdromemu.h: */

#define VERSION "CDROMEMU 1.1 (19.04.94)"

#define CMD_TERM	0x7ff0
#define CMD_STARTUP	0x7ff1
#define CMD_XXX_REMOVE	0x7ff2
#define CMD_XXX_INSERT	0x7ff3
