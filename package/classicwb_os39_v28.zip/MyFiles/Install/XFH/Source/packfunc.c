/* packfunc.c - declaration of packertype interface.
   Copyright (C) 1991, 1992, 1993 Kristian Nielsen.

   This file is part of XFH, the compressing file system handler.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            */

#include "CFS.h"

/* The struct cfsfunctions interface to the rest of the file system. */

/* In order to inhibit warnings about incompatible pointer assigns, the */
/* macro '_' is defined to be a cast to void *. */

#define _ (void *)

/* Xpk.library support. */
struct cfsfunctions Xpkfunc = {
  _ owt,           /* Cannot Open() from XpkLock (is a plain file). */
  _ Xpk_Read,      /* Read() */
  _ Xpk_Write,     /* Write() */
  _ Xpk_Seek,      /* Seek() */
  _ Xpk_Close,     /* Close() */
  _ ank,           /* SetFileSize() */
  _ ank,           /* LockRecord() */
  _ ank,           /* UnLockRecord() */
  _ owt,           /* Lock() */
  _ XpkDupLock,    /* DupLock() */
  _ XpkUnLock,     /* UnLock() */
  _ XpkObjExamine, /* Examine() */
  _ owt,           /* ExNext() */
  _ owt,           /* CreateDir() */
  _ owt,           /* DeleteFile() */
  _ owt,           /* Rename() */
  _ XpkParentDir,  /* Parent() */
  _ owt,           /* SetProtection() */
  _ owt,           /* SetComment() */
  _ owt,           /* SetFileDate() */
  _ ank,           /* OpenFromLock() */
  _ XpkSameLock,   /* SameLock() */
  _ owt,           /* MakeLink() */
  _ owt,           /* ReadLink() */
  _ ank,           /* ChangeMode() */
  _ ank,           /* DupLockFromFH() */
  _ XpkParentFH,   /* ParentOfFH() */
  _ owt,           /* ExAll() */
  _ XpkObjExamineFH, /* ExamineFH() */
  _ NULL,          /* StartNotify() */
  _ NULL,          /* EndNotify() */
};


/* XObj support (underlying file system). */
struct cfsfunctions Xfunc = {
  _ owt,           /* Cannot Open() from XObjLock. */
  _ XObjRead,      /* Read() */
  _ XObjWrite,     /* Write() */
  _ XObjSeek,      /* Seek() */
  _ XObjClose,     /* Close() */
  _ ank,           /* SetFileSize() */
  _ ank,           /* LockRecord() */
  _ ank,           /* UnLockRecord() */
  _ owt,           /* Lock() */
  _ XObjDupLock,   /* DupLock() */
  _ XObjUnLock,    /* UnLock() */
  _ XObjExamine,   /* Examine() */
  _ XObjExNext,    /* ExNext() */
  _ XObjCreateDir, /* CreateDir() */
  _ XObjDeleteFile, /* DeleteFile() */
  _ XObjRename,    /* Rename() */
  _ XObjParentDir, /* Parent() */
  _ XObjSetProtection, /* SetProtection() */
  _ XObjSetComment,  /* SetComment() */
  _ XObjSetFileDate, /* SetFileDate() */
  _ ank,           /* OpenFromLock() */
  _ XObjSameLock,  /* SameLock() */
  _ XObjMakeLink,  /* MakeLink() */
  _ XObjReadLink,  /* ReadLink() */
  _ ank,           /* ChangeMode() */
  _ ank,           /* DupLockFromFH() */
  _ XObjParentFH,  /* ParentOfFH() */
  _ owt,           /* ExAll() */
  _ XObjExamineFH, /* ExamineFH() */
  _ NULL,          /* StartNotify() */
  _ NULL,          /* EndNotify() */
};

#undef _


/* This function is called to fix the FIB to correctly reflect the */
/* result of unpacking the file (or archive). */
BOOL ModifyFIB_type( glb glob, LONG type, struct CFSLock *lock,
		    struct FileInfoBlock *fib, struct FileHandle *xfh ){
  
  switch(type){
  case XOBJECT:
    return XObjModifyFIB( glob, lock, fib, xfh );
  case XPKOBJECT:
    return XpkModifyFIB( glob, (struct XpkLock *)lock, fib, xfh );
  default:
    debug(("Error: ModifyFIB_type(): Bad object type %ld\n",type));
    glob->ioerr = ERROR_ACTION_NOT_KNOWN;
    return DOSFALSE;
  }
}


/* End of packfunc.c */
