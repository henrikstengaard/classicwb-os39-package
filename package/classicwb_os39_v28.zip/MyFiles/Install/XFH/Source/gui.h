#define XFHSEMAPHORENAME "� XFH �"

struct XFHNode
{
   struct Node xfh_Node; /* ln_Name contains device name without trailing ':' */
   UWORD xfh_Length;     /* length of XFHNode itself (for future enhancements) */
   struct MsgPort *xfh_Handler;   /* MsgPort of this device's handler */
   LONG xfh_PackerID;    /* 'NUKE', 'IMPL', and so on. May be NULL if the */
                         /* user hasn't selected a packer */
                         /* DEFAULT: 0 */
   UBYTE nullbyte;       /* always 0, this will guarantee a NULL-termination */
                         /* for xfh_PackerID when used as a string */
   UBYTE xfh_LowMemory;  /* if !0 use StepDown, create files on disk */
                         /* rather then in RAM, and try in any way to */
                         /* save memory */
                         /* DEFAULT: 0 */
   UBYTE xfh_AutoPack;   /* 0 don't compress files, !0 compress */
                         /* DEFAULT: 0 */
   UBYTE xfh_PackMode;   /* 0...100. Values out of range shall be converted */
                         /* to the packer's default mode */
   BPTR xfh_RootLock;    /* lock on the directory this device is mounted on, */
                         /* or NULL */
/* all fields down to this point are guaranteed to be there. In case of future */
/* enhancements, xfh_Length *MUST* be checked before accessing additional fields. */
};

struct XFHSemaphore
{
   struct SignalSemaphore xfh_Semaphore;
   struct List xfh_DeviceList;
   UWORD xfh_Length;              /* length of XFHSemaphore itself */
/* end of fields which will always be there */
};
