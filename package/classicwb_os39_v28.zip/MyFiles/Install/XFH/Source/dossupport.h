/* 'dossupport.h' - AmigaDOS support rutines. */

#ifndef EXEC_TYPES_H
#include <exec/types.h>
#endif

#ifndef DOS_DOS_H
#include <dos/dos.h>
#endif

/* Memory allocation. */
void	*dosalloc(LONG);
void	dosfree(void *);

/* dalloc(p) points pointer p to suitable sized allocated mem. */
/* The value of p is returned. */
#define dalloc(p) ( (p)=dosalloc( sizeof(*(p)) ) )
#define dfree(p) dosfree( (p) )

/* BCPL conversion. */
BSTR	cstr2b(STRPTR cstr, STRPTR buf);
STRPTR	bstr2c(BSTR bstr, STRPTR buf);
BSTR	cstr2binplace(STRPTR pp);
STRPTR	bstr2cinplace(STRPTR pp);

#define c2b(cptr) ( (ULONG)(cptr) >> 2 )
#define b2c(bptr) ( (void *)( (ULONG)(bptr) << 2) )

/* End of dossupport.h */
