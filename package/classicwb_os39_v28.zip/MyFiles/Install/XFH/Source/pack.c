/* pack.c - packer-support routines.
   Copyright (C) 1991, 1992, 1993 Kristian Nielsen.

   This file is part of XFH, the compressing file system handler.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            */

#include "CFS.h"
#include "dossupport.h"

#define MAKELONGID(a,b,c,d) \
( (ULONG)(a)<<24 | (ULONG)(b)<<16 | (ULONG)(c)<<8 | (ULONG)(d) )
#define LID_PACK MAKELONGID('P','A','C','K')
#ifdef NUKE_SUPPORT
#define LID_NUKE MAKELONGID('N','U','K','E')
#endif
#ifdef POWERPACKER_SUPPORT
#define LID_PP20 MAKELONGID('P','P','2','0')
#endif


#define GETID(id) xRead(glob, xfh, &(id), 4)

/* The purpose of this function is to determine what kind of file a
 * (x)filehandle belongs to. Currently, this is done with a massive 'if',
 * that is, it needs to be hardwired into the cfs. It would be nice to
 * have a more open system - something like a list that a set of shared
 * libraries could hook into, each catering for some subset of the
 * supported file types.
 *
 * An idea would be to have an ARexx interface. Not exactly fast, but
 * this way even the casual user could have the filesystem handle
 * almost any file conversion through the CFS themselves! (Say, like
 * converting graphics data in file format XYZZ12 from messydos machines
 * to IFF).
 *
 */
LONG xFileType( glb glob, struct FileHandle *xfh ){
   LONG objtype=XOBJECT;

   /* Check for a format recognisable by longword id. */
   /* (At this point in time, only XPK and XOBJ are supported). */
#ifdef OBSOLETE_PRE_XPK_PACKER_SUPPORT
   ULONG idbuf;

   if( GETID(idbuf) == 4) switch(idbuf){
      case LID_PACK:
         if( GETID(idbuf) == 4) switch( idbuf ){
#ifdef NUKE_SUPPORT
            case LID_NUKE:
               objtype = NUKEOBJECT;
               goto return_type;
#endif
            default:
               objtype = XPKOBJECT;
               goto return_type;
         }
         break;
#ifdef POWERPACKER_SUPPORT
      case LID_PP20:
         objtype = PPACKOBJ;
         goto return_type;
#endif
      default:
         break;          /* Unknown main id. */
   }
#endif

   /* If checking for another type, remember to xSeek() if nessesary. */
   debug(("Checking if file is Xpk..."));
   xSeek( glob, xfh, 0L, OFFSET_BEGINNING );
   if( IsXpkFile( glob, xfh )){
      debug(("YES!\n"));
      objtype = XPKOBJECT;
      goto return_type;
   }
   debug(("No.\n"));
   
 return_type:
   xSeek( glob, xfh, 0L, OFFSET_BEGINNING );
   return objtype;
}

#undef GETID

/* End of pack.c */
