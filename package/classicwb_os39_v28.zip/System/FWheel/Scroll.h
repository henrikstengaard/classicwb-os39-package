int DoScroll(struct WheelMouseContext *wmc,int axis,int direction);
struct Window *WindowUnderPointer();
